// liste des types en JS
let name = 'Del Piero'; // String
let age = 42; // Number
let retired = true; // Boolean
let team = null; // Null
let country = undefined; // Undefined (utilisé par le compilateur)

let teams = []; // Array

// Object
let player = {
  firstname: 'Alessandro',
  lastname: 'Del Piero',
  age: 42,
  retired: true,
  country: 'Italy'
}
