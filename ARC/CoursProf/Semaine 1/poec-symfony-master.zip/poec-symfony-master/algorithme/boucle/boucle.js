// La boucle POUR DE A
for (var compteur = 0; compteur < 10; compteur++) {
    console.log('Le compteur est à : ' + compteur);
}

// La boucle TANT QUE
var compteur = 0;
var villes = ['Paris', 'Marseille', 'Lyon', 'Lille', 'Strasbourg'];

while (compteur < villes.length) {
    console.log(compteur, villes[compteur]);
    compteur++;
}
