# Factorielle

## Annotation arithmétique
```math
n!
```

```math
0! = 1
1! = 1
2! = 2 * 1 = 2
3! = 3 * 2 * 1 = 6
4! = 4 * 3 * 2 * 1 = 24
6! = 6 * 5 * 4 * 3 * 2 * 1 = 720
```
