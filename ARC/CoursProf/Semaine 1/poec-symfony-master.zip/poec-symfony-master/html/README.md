# HTML

## Emmet formules

```html
ul.menu.toto#test>(li.item-$>a[href="#"]{Item $})*10
```

```html
(article>h2{Titre}+p>lorem5)*5
```

```html
.box${Box $}*7
```