(function () {

  var test = 'variable définie dans app3.js';

  function message() {
    console.log(test + ' *** ');
  }

  message();

})()
